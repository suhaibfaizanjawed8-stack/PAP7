import { access, readFile, readdir, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dist = path.join(root, 'dist');
const requiredRoutes = ['/', '/about/', '/products/', '/capabilities/', '/innovation/', '/quality/', '/industries/', '/portfolio/', '/journal/', '/contact/', '/case-studies/', '/privacy/', '/terms/'];
const requiredAssets = [
  '/assets/images/engravix.webp', '/assets/images/prod_cartons.jpg',
  '/assets/images/prod_leaflets.jpg', '/assets/images/prod_labels.jpg',
  '/assets/images/prod_tamper_labels.jpg', '/assets/images/coldseal.jpg',
  '/assets/images/engravix.jpg', '/assets/images/hero-3d-pharma-packaging.webp',
  '/assets/images/prince-art-packages-logo.jpg', '/assets/images/prince-art-packages-logo-3d.jpg',
  '/favicon.png'
];

const files = [];
async function walk(directory) {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const full = path.join(directory, entry.name);
    if (entry.isDirectory()) await walk(full); else files.push(full);
  }
}

const errors = [];
const checked = new Set();
const internal = new Set();
const toFile = (url) => {
  const clean = decodeURIComponent(url.split(/[?#]/)[0]);
  if (clean === '/') return path.join(dist, 'index.html');
  if (clean.endsWith('/')) return path.join(dist, clean.slice(1), 'index.html');
  return path.join(dist, clean.slice(1));
};

await walk(dist);
for (const file of files.filter((file) => file.endsWith('.html'))) {
  const html = await readFile(file, 'utf8');
  if (/C:\\|file:\/\/|localhost/i.test(html)) errors.push(`${file}: contains a local-only path`);
  if (/<img(?![^>]*\balt=)/i.test(html)) errors.push(`${file}: image without alt text`);
  const idSet = new Set([...html.matchAll(/\bid="([^"]+)"/g)].map((match) => match[1]));
  for (const match of html.matchAll(/(?:href|src)="([^"]+)"/g)) {
    const url = match[1];
    if (/^(?:https?:|mailto:|tel:|data:)/.test(url)) continue;
    if (url.startsWith('#')) {
      if (url.length > 1 && !idSet.has(url.slice(1))) errors.push(`${file}: missing local anchor ${url}`);
      continue;
    }
    if (!url.startsWith('/')) {
      errors.push(`${file}: non-root-relative link ${url}`);
      continue;
    }
    internal.add(url);
    const target = toFile(url);
    const key = `${file}|${url}`;
    if (checked.has(key)) continue;
    checked.add(key);
    try {
      const info = await stat(target);
      if (!info.isFile()) errors.push(`${file}: ${url} does not resolve to a file`);
      const hash = url.includes('#') ? url.split('#')[1] : '';
      if (hash && target.endsWith('.html')) {
        const targetHtml = await readFile(target, 'utf8');
        if (!new RegExp(`\\bid=["']${hash}["']`).test(targetHtml)) errors.push(`${file}: missing target anchor ${url}`);
      }
    } catch {
      errors.push(`${file}: broken internal reference ${url}`);
    }
  }
}

for (const route of requiredRoutes) {
  try { await access(toFile(route)); } catch { errors.push(`Missing required route ${route}`); }
}
for (const asset of requiredAssets) {
  try { await access(toFile(asset)); } catch { errors.push(`Missing required asset ${asset}`); }
}

if (errors.length) {
  console.error(`Broken links or assets found: ${errors.length}`);
  errors.forEach((error) => console.error(`- ${error}`));
  process.exit(1);
}

console.log(`Pages checked: ${files.filter((file) => file.endsWith('.html')).length}`);
console.log(`Internal URLs and assets checked: ${internal.size}`);
console.log('Broken links found: 0');
console.log('Missing assets found: 0');
