import { cp, mkdir, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { pages, homeContent, pageContent } from './content.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const src = path.join(root, 'src');
const dist = path.join(root, 'dist');
const origin = 'https://pap-5-kzq5.vercel.app';

const navItems = [
  ['/', 'Home'], ['/about/', 'About'], ['/products/', 'Products'],
  ['/capabilities/', 'Capabilities'], ['/innovation/', 'Innovation'],
  ['/quality/', 'Quality'], ['/industries/', 'Industries'],
  ['/portfolio/', 'Portfolio'], ['/contact/', 'Contact']
];

const header = (route) => `
  <header class="site-header ${route === '/' ? '' : 'inner'}">
    <div class="nav-shell">
      <a class="brand" href="/" aria-label="Prince Art Packages home">
        <span class="brand-logo-window"><img src="/assets/images/prince-art-packages-logo.jpg" alt="Prince Art Packages (Private) Limited" width="801" height="801"></span>
      </a>
      <button class="nav-toggle" type="button" aria-label="Open navigation" aria-expanded="false" aria-controls="main-navigation" data-nav-toggle>☰</button>
      <nav class="main-nav" id="main-navigation" aria-label="Main navigation" data-main-nav>
        ${navItems.map(([href, label]) => `<a href="${href}"${route === href ? ' aria-current="page"' : ''}>${label}</a>`).join('')}
      </nav>
      <a class="button gold" href="/contact/#enquiry-form">Request a quote <span class="arrow" aria-hidden="true">↗</span></a>
    </div>
  </header>`;

const footer = `
  <section class="cta-band">
    <div class="container cta-inner">
      <div><span class="eyebrow">Your next packaging project</span><h2>Let’s make precision happen.</h2></div>
      <a class="button light" href="/contact/">Contact our team <span aria-hidden="true">↗</span></a>
    </div>
  </section>
  <footer class="site-footer">
    <div class="container footer-main">
      <div class="footer-brand">
        <a class="brand footer-logo" href="/" aria-label="Prince Art Packages home"><span class="brand-logo-window"><img src="/assets/images/prince-art-packages-logo.jpg" alt="Prince Art Packages (Private) Limited" width="801" height="801" loading="lazy"></span></a>
        <p>Precision secondary packaging for pharmaceutical, healthcare, medical and other regulated products.</p>
      </div>
      <div><div class="footer-title">Company</div><div class="footer-links"><a href="/about/">About us</a><a href="/capabilities/">Capabilities</a><a href="/quality/">Quality</a><a href="/portfolio/">Portfolio</a><a href="/journal/">Journal</a></div></div>
      <div><div class="footer-title">Packaging</div><div class="footer-links"><a href="/products/">All products</a><a href="/products/#pharmaceutical-cartons">Pharmaceutical cartons</a><a href="/products/#luxury-rigid-boxes">Luxury rigid boxes</a><a href="/products/#electronics-mobile">Electronics packaging</a><a href="/innovation/">Innovation</a><a href="/industries/">Industries</a></div></div>
      <div><div class="footer-title">Contact</div><div class="footer-links"><a href="mailto:sales@princeartpackages.com">sales@princeartpackages.com</a><a href="tel:+9221388934003">+92 21-38893400-3</a><span>Korangi Creek Industrial Park<br>Karachi, Pakistan</span></div></div>
    </div>
    <div class="container footer-bottom"><span>© 2026 Prince Art Packages (Private) Limited</span><div class="footer-legal"><a href="/privacy/">Privacy policy</a><a href="/terms/">Terms &amp; conditions</a></div></div>
  </footer>`;

const pageHero = (page) => `
  <section class="page-hero">
    <div class="page-hero-bg"><img src="${page.image}" alt="${page.imageAlt}" width="1600" height="900" fetchpriority="high"></div>
    <div class="page-hero-inner">
      <div class="breadcrumbs"><a href="/">Home</a> / ${page.nav}</div>
      <span class="eyebrow">${page.eyebrow}</span>
      <h1>${page.heading}</h1>
      <p>${page.description}</p>
    </div>
  </section>`;

const documentHtml = (page, content) => {
  const canonical = `${origin}${page.route}`;
  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${page.title}</title>
  <meta name="description" content="${page.meta}">
  <link rel="canonical" href="${canonical}">
  <meta property="og:type" content="website">
  <meta property="og:title" content="${page.title}">
  <meta property="og:description" content="${page.meta}">
  <meta property="og:url" content="${canonical}">
  <meta property="og:image" content="${origin}/assets/images/prince-art-packages-logo.jpg">
  <meta name="twitter:card" content="summary">
  <meta name="theme-color" content="#061d33">
  <link rel="icon" href="/favicon.png" type="image/png">
  <link rel="stylesheet" href="/assets/styles.css">
  <script src="/assets/site.js" defer></script>
</head>
<body${page.route === '/' ? ' class="is-home"' : ''}>
  <a class="skip-link" href="#main-content">Skip to content</a>
  ${header(page.route)}
  <main id="main-content">${content}</main>
  ${footer}
</body>
</html>`;
};

await rm(dist, { recursive: true, force: true });
await mkdir(path.join(dist, 'assets', 'images'), { recursive: true });
await cp(path.join(src, 'assets', 'images'), path.join(dist, 'assets', 'images'), { recursive: true });
await cp(path.join(src, 'styles.css'), path.join(dist, 'assets', 'styles.css'));
await cp(path.join(src, 'site.js'), path.join(dist, 'assets', 'site.js'));
await Promise.all(['favicon.png', 'robots.txt', 'sitemap.xml'].map((name) => cp(path.join(src, name), path.join(dist, name))));

for (const page of pages) {
  const content = page.route === '/' ? homeContent : `${pageHero(page)}${pageContent[page.route]}`;
  const directory = page.route === '/' ? dist : path.join(dist, page.route.slice(1, -1));
  await mkdir(directory, { recursive: true });
  await writeFile(path.join(directory, 'index.html'), documentHtml(page, content), 'utf8');
}

console.log(`Built ${pages.length} pages in ${dist}`);
