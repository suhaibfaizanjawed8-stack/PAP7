(() => {
  const toggle = document.querySelector('[data-nav-toggle]');
  const nav = document.querySelector('[data-main-nav]');

  const closeMenu = () => {
    if (!toggle || !nav) return;
    nav.classList.remove('open');
    toggle.setAttribute('aria-expanded', 'false');
    toggle.textContent = '☰';
    document.body.classList.remove('nav-open');
  };

  toggle?.addEventListener('click', () => {
    const open = toggle.getAttribute('aria-expanded') !== 'true';
    nav.classList.toggle('open', open);
    toggle.setAttribute('aria-expanded', String(open));
    toggle.textContent = open ? '×' : '☰';
    document.body.classList.toggle('nav-open', open);
  });

  nav?.querySelectorAll('a').forEach((link) => link.addEventListener('click', closeMenu));
  document.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeMenu(); });

  const observer = 'IntersectionObserver' in window
    ? new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('visible');
            observer.unobserve(entry.target);
          }
        });
      }, { threshold: 0.12 })
    : null;

  document.querySelectorAll('.reveal').forEach((element) => {
    if (observer) observer.observe(element); else element.classList.add('visible');
  });

  const form = document.querySelector('[data-quote-form]');
  const status = document.querySelector('[data-form-status]');
  form?.addEventListener('submit', (event) => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const data = new FormData(form);
    const lines = [
      `Full name: ${data.get('fullName')}`,
      `Company: ${data.get('company')}`,
      `Business email: ${data.get('email')}`,
      `Phone / WhatsApp: ${data.get('phone') || 'Not provided'}`,
      `Country: ${data.get('country')}`,
      `Product type: ${data.get('productType') || 'Not specified'}`,
      `Estimated quantity: ${data.get('quantity') || 'Not specified'}`,
      `Packaging requirement: ${data.get('requirement')}`,
      '',
      `Message: ${data.get('message')}`
    ];
    const subject = encodeURIComponent(`Packaging enquiry — ${data.get('company')}`);
    const body = encodeURIComponent(lines.join('\n'));
    if (status) status.textContent = 'Your email application will open with the enquiry prepared. Nothing is sent until you send it.';
    window.location.href = `mailto:sales@princeartpackages.com?subject=${subject}&body=${body}`;
  });
})();
