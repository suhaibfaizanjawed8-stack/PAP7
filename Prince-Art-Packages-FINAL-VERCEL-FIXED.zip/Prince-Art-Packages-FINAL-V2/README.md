# Prince Art Packages — Final Vercel/GitHub Package

This is a static multi-page website prepared for Vercel deployment.

## GitHub
Extract the ZIP and upload the **contents of this folder** to the repository root. Do not upload only the ZIP file.

The repository root should contain `index.html`, `package.json`, `vercel.json`, `scripts/`, `assets/`, and the page folders.

## Vercel
Import the GitHub repository into Vercel. The included `vercel.json` is configured to:

- run `npm run build`
- create a real `dist/` deployment folder
- publish `dist/`

Normally no manual Build Command or Output Directory override is needed. If Vercel has old overrides saved in Project Settings, reset them to use the repository configuration.

## Local verification

```bash
npm run check
npm run build
```

A successful build prints that the website was copied to `dist/`.
