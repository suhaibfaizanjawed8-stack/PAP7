import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const out = path.join(root, 'dist');
const excludedTopLevel = new Set([
  '.git', '.github', '.vercel', 'dist', 'node_modules', 'scripts',
  'package.json', 'package-lock.json', 'vercel.json', 'README.md', '.gitignore'
]);

function copyEntry(src, dest) {
  const stat = fs.statSync(src);
  if (stat.isDirectory()) {
    fs.mkdirSync(dest, { recursive: true });
    for (const name of fs.readdirSync(src)) copyEntry(path.join(src, name), path.join(dest, name));
  } else if (stat.isFile()) {
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(src, dest);
  }
}

if (!fs.existsSync(path.join(root, 'index.html'))) {
  console.error('Build failed: root index.html is missing.');
  process.exit(1);
}

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });

for (const name of fs.readdirSync(root)) {
  if (excludedTopLevel.has(name)) continue;
  copyEntry(path.join(root, name), path.join(out, name));
}

if (!fs.existsSync(path.join(out, 'index.html'))) {
  console.error('Build failed: dist/index.html was not created.');
  process.exit(1);
}
if (!fs.existsSync(path.join(out, 'assets', 'images', 'logo.png'))) {
  console.error('Build failed: official logo missing from dist/assets/images/logo.png.');
  process.exit(1);
}

const htmlCount = (() => {
  let n = 0;
  const walk = d => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) walk(p);
      else if (e.isFile() && e.name.endsWith('.html')) n++;
    }
  };
  walk(out);
  return n;
})();

console.log(`Build complete: ${htmlCount} HTML pages copied to dist/.`);
console.log('Vercel output directory: dist');
