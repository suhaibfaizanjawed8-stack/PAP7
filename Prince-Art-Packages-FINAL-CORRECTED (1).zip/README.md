# Prince Art Packages — FINAL

This is the complete static website package for Prince Art Packages (Private) Limited.

## Important
Upload the **contents of this folder** to the root of your GitHub repository. Do not upload only the ZIP file into GitHub.

The repository root should show files/folders such as:

- `index.html`
- `about/`
- `products/`
- `assets/`
- `design.css`
- `brand-colors.css`
- `interactions.js`
- `package.json`
- `scripts/`
- `vercel.json`

## Vercel
Import the GitHub repository into Vercel.

Recommended project settings:

- Framework Preset: **Other**
- Root Directory: `./`
- Build Command: `npm run build`
- Output Directory: `.`

`npm run build` performs a verification check only. The website itself is already static and ready to serve.

## Local verification

```bash
npm run build
```

The command checks the official logo, pages, local images/assets, stylesheet references, and internal links.

## Why the previous deployment failed
The previous tiny `PAP-FINAL` package referenced `scripts/build.mjs`, but those project files were not present at the GitHub repository root. This final package contains the real website directly at the repository root and a build/check script that exists in the repository.
